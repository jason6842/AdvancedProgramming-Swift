//
//  LittleLemonDinnerMenuTests.swift
//  LittleLemonDinnerMenuTests
//
//  Created by Jason Ma on 12/2/24.
//

import Testing
@testable import LittleLemonDinnerMenu

struct LittleLemonDinnerMenuTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
