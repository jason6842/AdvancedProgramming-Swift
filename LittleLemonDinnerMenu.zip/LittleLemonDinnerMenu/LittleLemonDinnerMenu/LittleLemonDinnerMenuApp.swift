//
//  LittleLemonDinnerMenuApp.swift
//  LittleLemonDinnerMenu
//
//  Created by Jason Ma on 12/2/24.
//

import SwiftUI

@main
struct LittleLemonDinnerMenuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
